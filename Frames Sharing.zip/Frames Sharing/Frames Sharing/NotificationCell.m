//
//  NotificationCell.m
//  Frames Sharing
//
//  Created by sadmin on 5/5/13.
//  Copyright (c) 2013 Blue Plover Productions. All rights reserved.
//

#import "NotificationCell.h"

@implementation NotificationCell

@end
