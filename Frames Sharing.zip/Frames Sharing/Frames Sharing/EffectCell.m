//
//  EffectCell.m
//  iPictureFrames Lite
//
//  Created by sadmin on 12/29/12.
//  Copyright (c) 2012 Janusz Chudzynski. All rights reserved.
//

#import "EffectCell.h"

@implementation EffectCell

@end
