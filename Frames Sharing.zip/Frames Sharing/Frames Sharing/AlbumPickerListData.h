//
//  AlbumPickerListData.h
//  Frames Sharing
//
//  Created by sadmin on 4/3/13.
//  Copyright (c) 2013 Blue Plover Productions. All rights reserved.
//

#import "AlbumListData.h"

@interface AlbumPickerListData : AlbumListData

@end
