//
//  PFiPadAlbumsViewController.h
//  Frames Sharing
//
//  Created by Janusz Chudzynski on 3/25/13.
//  Copyright (c) 2013 Blue Plover Productions. All rights reserved.
//

#import <Foundation/Foundation.h>
@class User;

@interface PFiPadAlbumsViewController : UIViewController
@property (nonatomic,strong) User * user;
@end
