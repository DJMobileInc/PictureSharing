//
//  ContentPack.m
//  iPictureFrames Lite
//
//  Created by sadmin on 12/22/12.
//  Copyright (c) 2012 Janusz Chudzynski. All rights reserved.
//

#import "ContentPack.h"
#import "Content.h"
@implementation ContentPack

@end
