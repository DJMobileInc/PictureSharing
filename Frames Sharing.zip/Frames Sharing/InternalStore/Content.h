//
//  Content.h
//  iPictureFrames Lite
//
//  Created by sadmin on 12/22/12.
//  Copyright (c) 2012 Janusz Chudzynski. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Content : NSObject
@property(nonatomic) NSMutableArray * images;
@property(nonatomic) NSMutableArray * thumbnails;
@end
