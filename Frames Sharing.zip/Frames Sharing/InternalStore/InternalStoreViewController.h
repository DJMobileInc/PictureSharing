//
//  InternalStoreViewController.h
//  GiftMaker
//
//  Created by Janusz Chudzynski on 11/27/12.
//  Copyright (c) 2012 Janusz Chudzynski. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InternalStoreViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
- (IBAction)restorePurchases:(id)sender;

@end
