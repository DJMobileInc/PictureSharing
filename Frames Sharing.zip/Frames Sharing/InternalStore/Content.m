//
//  Content.m
//  iPictureFrames Lite
//
//  Created by sadmin on 12/22/12.
//  Copyright (c) 2012 Janusz Chudzynski. All rights reserved.
//

#import "Content.h"

@implementation Content

@end
