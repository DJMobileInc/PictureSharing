//
//  StoreItemDetailViewController.h
//  GiftMaker
//
//  Created by Janusz Chudzynski on 11/30/12.
//  Copyright (c) 2012 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContentPack.h"
#import "Content.h"

@interface StoreItemDetailViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@property (strong) UIImage * image;
@end
