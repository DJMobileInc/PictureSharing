//
//  RotatingNavigationControllerViewController.h
//  Frames Sharing
//
//  Created by Janusz Chudzynski on 4/19/13.
//  Copyright (c) 2013 Blue Plover Productions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RotatingNavigationControllerViewController : UINavigationController

@end
