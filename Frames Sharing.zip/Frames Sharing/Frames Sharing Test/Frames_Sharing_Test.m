//
//  Frames_Sharing_Test.m
//  Frames Sharing Test
//
//  Created by sadmin on 3/10/13.
//  Copyright (c) 2013 Blue Plover Productions. All rights reserved.
//

#import "Frames_Sharing_Test.h"

@implementation Frames_Sharing_Test

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Frames Sharing Test");
}

@end
