//
//  Frames_Sharing_Test.h
//  Frames Sharing Test
//
//  Created by sadmin on 3/10/13.
//  Copyright (c) 2013 Blue Plover Productions. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Frames_Sharing_Test : SenTestCase

@end
